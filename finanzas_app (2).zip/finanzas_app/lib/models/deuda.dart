class Deuda {
  final String descripcion;
  final double montoInicial;
  final double tasaMensual;

  Deuda({
    required this.descripcion,
    required this.montoInicial,
    required this.tasaMensual,
  });

  double calcularDeuda(int meses) {
    double a = tasaMensual / 100;
    return montoInicial + (a * meses * meses) + (a * meses);
  }
}