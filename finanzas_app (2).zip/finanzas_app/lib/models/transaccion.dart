class Transaccion {
  final String id;
  final String descripcion;
  final double monto;
  final String tipo;
  final DateTime fecha;

  Transaccion({
    required this.id,
    required this.descripcion,
    required this.monto,
    required this.tipo,
    required this.fecha,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'descripcion': descripcion,
      'monto': monto,
      'tipo': tipo,
      'fecha': fecha.toIso8601String(),
    };
  }

  factory Transaccion.fromMap(Map<String, dynamic> map) {
    return Transaccion(
      id: map['id'],
      descripcion: map['descripcion'],
      monto: map['monto'],
      tipo: map['tipo'],
      fecha: DateTime.parse(map['fecha']),
    );
  }
}