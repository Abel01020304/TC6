class Ahorro {
  final double montoInicial;
  final double tasaInteres;
  final int anos;

  Ahorro({
    required this.montoInicial,
    required this.tasaInteres,
    required this.anos,
  });

  double calcularFinal() {
    return montoInicial * (1 + tasaInteres / 100) * anos;
  }
}