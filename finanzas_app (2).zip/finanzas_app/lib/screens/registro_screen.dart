import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/transaccion.dart';
import '../utils/finanzas_provider.dart';
import '../utils/constantes.dart';

class RegistroScreen extends StatefulWidget {
  const RegistroScreen({super.key});

  @override
  State<RegistroScreen> createState() => _RegistroScreenState();
}

class _RegistroScreenState extends State<RegistroScreen> {
  final _descController  = TextEditingController();
  final _montoController = TextEditingController();
  String _tipo = 'ingreso';

  void _guardar() {
    final desc  = _descController.text.trim();
    final monto = double.tryParse(_montoController.text.trim());

    if (desc.isEmpty || monto == null || monto <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Completa todos los campos correctamente'),
          backgroundColor: colorGasto,
        ),
      );
      return;
    }

    final t = Transaccion(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      descripcion: desc,
      monto: monto,
      tipo: _tipo,
      fecha: DateTime.now(),
    );

    context.read<FinanzasProvider>().agregar(t);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colorFondo,
      appBar: AppBar(
        title: const Text('Registrar movimiento', style: TextStyle(color: Colors.white)),
        backgroundColor: colorFondo,
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // Descripción
            Text('Descripción', style: TextStyle(color: colorTextoSub, fontSize: 13)),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: colorCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: colorCardBorde),
              ),
              child: TextField(
                controller: _descController,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'Ej: Sueldo, Renta, Comida...',
                  hintStyle: TextStyle(color: colorTextoSub),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.all(14),
                  prefixIcon: Icon(Icons.edit, color: colorTextoSub, size: 18),
                ),
              ),
            ),

            const SizedBox(height: 16),

            // Monto
            Text('Monto', style: TextStyle(color: colorTextoSub, fontSize: 13)),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: colorCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: colorCardBorde),
              ),
              child: TextField(
                controller: _montoController,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: '0.00',
                  hintStyle: TextStyle(color: colorTextoSub),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.all(14),
                  prefixIcon: Icon(Icons.attach_money, color: colorIngreso, size: 18),
                ),
              ),
            ),

            const SizedBox(height: 16),

            // Tipo
            Text('Tipo de movimiento', style: TextStyle(color: colorTextoSub, fontSize: 13)),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: colorCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: colorCardBorde),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _tipo,
                  isExpanded: true,
                  dropdownColor: colorCard,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  icon: Icon(Icons.keyboard_arrow_down, color: colorTextoSub),
                  items: const [
                    DropdownMenuItem(value: 'ingreso',  child: Text('💰 Ingreso')),
                    DropdownMenuItem(value: 'fijo',     child: Text('🏠 Gasto fijo')),
                    DropdownMenuItem(value: 'variable', child: Text('🛒 Gasto variable')),
                    DropdownMenuItem(value: 'deuda',    child: Text('💳 Deuda')),
                  ],
                  onChanged: (v) => setState(() => _tipo = v!),
                ),
              ),
            ),

            const SizedBox(height: 32),

            // Botón guardar
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _guardar,
                style: ElevatedButton.styleFrom(
                  backgroundColor: colorIngreso,
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: const Text('Guardar', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}