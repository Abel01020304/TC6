import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constantes.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _userController = TextEditingController();
  final _passController = TextEditingController();
  bool _verPassword = false;
  bool _error = false;
  String _mensajeError = '';

  void _login() async {
    final user = _userController.text.trim();
    final pass = _passController.text.trim();

    if (user.isEmpty || pass.isEmpty) {
      setState(() {
        _error = true;
        _mensajeError = 'Completa todos los campos';
      });
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    final userGuardado = prefs.getString('usuario');
    final passGuardada = prefs.getString('password');

    if (user == userGuardado && pass == passGuardada) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    } else {
      setState(() {
        _error = true;
        _mensajeError = 'Usuario o contraseña incorrectos';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colorFondo,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: colorIngreso.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: colorIngreso.withOpacity(0.3)),
                  ),
                  child: Icon(Icons.account_balance_wallet,
                      color: colorIngreso, size: 48),
                ),
                const SizedBox(height: 24),
                const Text('Mis Finanzas',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text('Inicia sesión para continuar',
                    style: TextStyle(color: colorTextoSub, fontSize: 14)),
                const SizedBox(height: 40),

                _campo(
                  controller: _userController,
                  hint: 'Usuario',
                  icono: Icons.person_outline,
                  oculto: false,
                ),
                const SizedBox(height: 14),
                _campo(
                  controller: _passController,
                  hint: 'Contraseña',
                  icono: Icons.lock_outline,
                  oculto: !_verPassword,
                  sufijo: IconButton(
                    icon: Icon(
                      _verPassword ? Icons.visibility_off : Icons.visibility,
                      color: colorTextoSub,
                      size: 20,
                    ),
                    onPressed: () =>
                        setState(() => _verPassword = !_verPassword),
                  ),
                ),

                if (_error) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: colorGasto.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: colorGasto.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.error_outline, color: colorGasto, size: 18),
                        const SizedBox(width: 8),
                        Text(_mensajeError,
                            style:
                                TextStyle(color: colorGasto, fontSize: 13)),
                      ],
                    ),
                  ),
                ],

                const SizedBox(height: 28),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _login,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: colorIngreso,
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                    ),
                    child: const Text('Iniciar sesión',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                  ),
                ),

                const SizedBox(height: 16),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('¿No tienes cuenta? ',
                        style:
                            TextStyle(color: colorTextoSub, fontSize: 14)),
                    GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const RegisterScreen()),
                      ),
                      child: Text('Regístrate',
                          style: TextStyle(
                              color: colorIngreso,
                              fontSize: 14,
                              fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _campo({
    required TextEditingController controller,
    required String hint,
    required IconData icono,
    required bool oculto,
    Widget? sufijo,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: colorCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colorCardBorde),
      ),
      child: TextField(
        controller: controller,
        obscureText: oculto,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: colorTextoSub),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.all(14),
          prefixIcon: Icon(icono, color: colorTextoSub, size: 20),
          suffixIcon: sufijo,
        ),
      ),
    );
  }
}

// ─── PANTALLA DE REGISTRO ───────────────────────────────────────────────────

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _userController  = TextEditingController();
  final _passController  = TextEditingController();
  final _pass2Controller = TextEditingController();
  bool _verPass  = false;
  bool _verPass2 = false;
  bool _error    = false;
  String _mensajeError = '';

  void _registrar() async {
    final user  = _userController.text.trim();
    final pass  = _passController.text.trim();
    final pass2 = _pass2Controller.text.trim();

    if (user.isEmpty || pass.isEmpty || pass2.isEmpty) {
      setState(() {
        _error = true;
        _mensajeError = 'Completa todos los campos';
      });
      return;
    }

    if (pass != pass2) {
      setState(() {
        _error = true;
        _mensajeError = 'Las contraseñas no coinciden';
      });
      return;
    }

    if (pass.length < 4) {
      setState(() {
        _error = true;
        _mensajeError = 'La contraseña debe tener al menos 4 caracteres';
      });
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('usuario', user);
    await prefs.setString('password', pass);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('¡Cuenta creada! Ahora inicia sesión.'),
          backgroundColor: colorIngreso,
        ),
      );
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: colorFondo,
      appBar: AppBar(
        title: const Text('Crear cuenta',
            style: TextStyle(color: Colors.white)),
        backgroundColor: colorFondo,
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(28),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: colorIngreso.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(24),
                    border:
                        Border.all(color: colorIngreso.withOpacity(0.3)),
                  ),
                  child: Icon(Icons.person_add_alt_1,
                      color: colorIngreso, size: 48),
                ),
                const SizedBox(height: 20),
                const Text('Crea tu cuenta',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text('Llena los campos para registrarte',
                    style:
                        TextStyle(color: colorTextoSub, fontSize: 14)),
                const SizedBox(height: 36),

                _campo(
                  controller: _userController,
                  hint: 'Nombre de usuario',
                  icono: Icons.person_outline,
                  oculto: false,
                ),
                const SizedBox(height: 14),
                _campo(
                  controller: _passController,
                  hint: 'Contraseña',
                  icono: Icons.lock_outline,
                  oculto: !_verPass,
                  sufijo: IconButton(
                    icon: Icon(
                      _verPass ? Icons.visibility_off : Icons.visibility,
                      color: colorTextoSub, size: 20,
                    ),
                    onPressed: () =>
                        setState(() => _verPass = !_verPass),
                  ),
                ),
                const SizedBox(height: 14),
                _campo(
                  controller: _pass2Controller,
                  hint: 'Confirmar contraseña',
                  icono: Icons.lock_outline,
                  oculto: !_verPass2,
                  sufijo: IconButton(
                    icon: Icon(
                      _verPass2 ? Icons.visibility_off : Icons.visibility,
                      color: colorTextoSub, size: 20,
                    ),
                    onPressed: () =>
                        setState(() => _verPass2 = !_verPass2),
                  ),
                ),

                if (_error) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: colorGasto.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                      border:
                          Border.all(color: colorGasto.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.error_outline,
                            color: colorGasto, size: 18),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(_mensajeError,
                              style: TextStyle(
                                  color: colorGasto, fontSize: 13)),
                        ),
                      ],
                    ),
                  ),
                ],

                const SizedBox(height: 28),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _registrar,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: colorIngreso,
                      foregroundColor: Colors.black,
                      padding:
                          const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                    ),
                    child: const Text('Crear cuenta',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                  ),
                ),

                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('¿Ya tienes cuenta? ',
                        style: TextStyle(
                            color: colorTextoSub, fontSize: 14)),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Text('Inicia sesión',
                          style: TextStyle(
                              color: colorIngreso,
                              fontSize: 14,
                              fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _campo({
    required TextEditingController controller,
    required String hint,
    required IconData icono,
    required bool oculto,
    Widget? sufijo,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: colorCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colorCardBorde),
      ),
      child: TextField(
        controller: controller,
        obscureText: oculto,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: colorTextoSub),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.all(14),
          prefixIcon: Icon(icono, color: colorTextoSub, size: 20),
          suffixIcon: sufijo,
        ),
      ),
    );
  }
}