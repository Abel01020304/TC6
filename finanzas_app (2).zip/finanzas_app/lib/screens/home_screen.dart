import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../utils/constantes.dart';
import '../utils/formatear.dart';
import '../utils/finanzas_provider.dart';
import '../models/transaccion.dart';
import '../funciones/funcion_tramos.dart';
import 'registro_screen.dart';
import 'graficas_screen.dart';
import 'prediccion_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final fp = context.watch<FinanzasProvider>();
    final tramos = FuncionTramos();
    final tramoDesc = tramos.descripcionTramo(fp.totalGastos);
    final bool alerta = fp.totalGastos > limiteAlerta;

    return Scaffold(
      backgroundColor: colorFondo,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 160,
            floating: false,
            pinned: true,
            backgroundColor: colorFondo,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF0A0A0A), Color(0xFF1A1A1A)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: colorIngreso.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Icon(Icons.account_balance_wallet, color: colorIngreso, size: 22),
                            ),
                            const SizedBox(width: 12),
                            const Text('Mis Finanzas',
                                style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Text('Ahorro total',
                            style: TextStyle(color: colorTextoSub, fontSize: 13)),
                        Text(formatearMoneda(fp.ahorro),
                            style: TextStyle(color: colorIngreso, fontSize: 28, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    children: [
                      _tarjeta('Ingresos', formatearMoneda(fp.totalIngresos), colorIngreso, Icons.arrow_upward),
                      const SizedBox(width: 10),
                      _tarjeta('Gastos', formatearMoneda(fp.totalGastos), colorGasto, Icons.arrow_downward),
                      const SizedBox(width: 10),
                      _tarjeta('Ahorro', formatearMoneda(fp.ahorro), colorAhorro, Icons.savings),
                    ],
                  ),
                  const SizedBox(height: 14),

                  // Alerta
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: alerta ? colorGasto.withOpacity(0.1) : colorIngreso.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: alerta ? colorGasto.withOpacity(0.3) : colorIngreso.withOpacity(0.2),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          alerta ? Icons.warning_amber_rounded : Icons.check_circle,
                          color: alerta ? colorGasto : colorIngreso,
                          size: 20,
                        ),
                        const SizedBox(width: 10),
                        Text(
                          alerta ? '⚠️ $tramoDesc' : '✅ $tramoDesc',
                          style: TextStyle(
                            color: alerta ? colorGasto : colorIngreso,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 14),

                  // Botones
                  Row(
                    children: [
                      Expanded(child: _boton('+ Registrar', Icons.add_circle_outline, colorIngreso, () =>
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const RegistroScreen())))),
                      const SizedBox(width: 10),
                      Expanded(child: _boton('Gráficas', Icons.bar_chart, colorAhorro, () =>
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const GraficasScreen())))),
                      const SizedBox(width: 10),
                      Expanded(child: _boton('Predicción', Icons.auto_graph, colorDeuda, () =>
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const PrediccionScreen())))),
                    ],
                  ),

                  const SizedBox(height: 22),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Movimientos recientes',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white)),
                      Text('${fp.transacciones.length} total',
                          style: TextStyle(fontSize: 12, color: colorTextoSub)),
                    ],
                  ),
                  const SizedBox(height: 12),

                  fp.transacciones.isEmpty
                      ? Container(
                          padding: const EdgeInsets.all(30),
                          decoration: BoxDecoration(
                            color: colorCard,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: colorCardBorde),
                          ),
                          child: Center(
                            child: Column(
                              children: [
                                Icon(Icons.receipt_long, size: 40, color: colorTextoSub),
                                const SizedBox(height: 8),
                                Text('Sin movimientos aún', style: TextStyle(color: colorTextoSub)),
                              ],
                            ),
                          ),
                        )
                      : ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: fp.transacciones.length,
                          itemBuilder: (_, i) {
                            final t = fp.transacciones[fp.transacciones.length - 1 - i];
                            return _itemTransaccion(t);
                          },
                        ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tarjeta(String label, String valor, Color color, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: colorCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.25)),
          boxShadow: [BoxShadow(color: color.withOpacity(0.08), blurRadius: 10)],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(height: 6),
            Text(label, style: TextStyle(fontSize: 11, color: colorTextoSub)),
            const SizedBox(height: 2),
            Text(valor, style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: color)),
          ],
        ),
      ),
    );
  }

  Widget _boton(String label, IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 4),
            Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }

  Widget _itemTransaccion(Transaccion t) {
    final color = t.tipo == 'ingreso' ? colorIngreso : colorGasto;
    final signo = t.tipo == 'ingreso' ? '+' : '-';
    final iconos = {
      'ingreso': Icons.arrow_upward,
      'fijo': Icons.home,
      'variable': Icons.shopping_cart,
      'deuda': Icons.credit_card,
    };
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: colorCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: colorCardBorde),
      ),
      child: Row(
        children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(iconos[t.tipo] ?? Icons.attach_money, color: color, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(t.descripcion, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14, color: Colors.white)),
                Text(t.tipo, style: TextStyle(fontSize: 12, color: colorTextoSub)),
              ],
            ),
          ),
          Text('$signo${formatearMoneda(t.monto)}',
              style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 14)),
        ],
      ),
    );
  }
}