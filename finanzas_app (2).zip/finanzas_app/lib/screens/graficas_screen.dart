import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import '../utils/constantes.dart';
import '../utils/finanzas_provider.dart';
import '../funciones/funcion_lineal.dart';
import '../funciones/funcion_constante.dart';
import '../funciones/funcion_cuadratica.dart';
import '../funciones/funcion_tramos.dart';

class GraficasScreen extends StatelessWidget {
  const GraficasScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final fp = context.watch<FinanzasProvider>();
    final lineal = FuncionLineal(m: 100, b: 0);
    final constante = FuncionConstante(k: fp.totalGastos == 0 ? 2000 : fp.totalGastos);
    final cuadratica = FuncionCuadratica(a: 0.5, b: 10, c: fp.totalGastos);
    final tramos = FuncionTramos();
    final tramoActual = tramos.evaluarTramo(fp.totalGastos);

    final puntosLineal = lineal.generarPuntos(10);
    final puntosCuadratica = cuadratica.generarPuntos(10);

    Color tramoColor = tramoActual == 'basico'
        ? colorIngreso
        : tramoActual == 'medio'
            ? colorDeuda
            : colorGasto;

    return Scaffold(
      backgroundColor: colorFondo,
      appBar: AppBar(
        title: const Text('Gráficas', style: TextStyle(color: Colors.white)),
        backgroundColor: colorFondo,
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [

            // Función por tramos
            _card(
              title: '📊 Función por tramos',
              subtitle: 'Nivel de gasto actual',
              child: Column(
                children: [
                  Row(
                    children: [
                      _tramo('0–\$1k', 'Básico', colorIngreso, tramoActual == 'basico'),
                      const SizedBox(width: 8),
                      _tramo('\$1k–\$3k', 'Medio', colorDeuda, tramoActual == 'medio'),
                      const SizedBox(width: 8),
                      _tramo('+\$3k', 'Alto', colorGasto, tramoActual == 'alto'),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: tramoColor.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: tramoColor.withOpacity(0.2)),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.info_outline, color: tramoColor, size: 18),
                        const SizedBox(width: 8),
                        Text(tramos.descripcionTramo(fp.totalGastos),
                            style: TextStyle(color: tramoColor, fontWeight: FontWeight.w500)),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 14),

            // Función lineal
            _card(
              title: '📈 Función lineal',
              subtitle: 'G(t) = 100t + 0',
              child: SizedBox(
                height: 180,
                child: LineChart(LineChartData(
                  gridData: FlGridData(
                    show: true,
                    getDrawingHorizontalLine: (_) => FlLine(
                        color: Colors.white.withOpacity(0.05), strokeWidth: 1),
                  ),
                  borderData: FlBorderData(show: false),
                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 40,
                      getTitlesWidget: (v, _) => Text(v.toInt().toString(),
                          style: TextStyle(color: colorTextoSub, fontSize: 10)),
                    )),
                    bottomTitles: AxisTitles(sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (v, _) => Text(v.toInt().toString(),
                          style: TextStyle(color: colorTextoSub, fontSize: 10)),
                    )),
                    topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  ),
                  lineBarsData: [
                    LineChartBarData(
                      spots: puntosLineal.asMap().entries
                          .map((e) => FlSpot(e.key.toDouble(), e.value)).toList(),
                      isCurved: false,
                      color: colorIngreso,
                      barWidth: 3,
                      dotData: const FlDotData(show: false),
                      belowBarData: BarAreaData(
                          show: true, color: colorIngreso.withOpacity(0.08)),
                    ),
                  ],
                )),
              ),
            ),

            const SizedBox(height: 14),

            // Función constante
            _card(
              title: '📉 Función constante',
              subtitle: 'f(t) = k (gastos fijos)',
              child: SizedBox(
                height: 130,
                child: LineChart(LineChartData(
                  gridData: FlGridData(show: false),
                  borderData: FlBorderData(show: false),
                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 50,
                      getTitlesWidget: (v, _) => Text(v.toInt().toString(),
                          style: TextStyle(color: colorTextoSub, fontSize: 10)),
                    )),
                    bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  ),
                  lineBarsData: [
                    LineChartBarData(
                      spots: List.generate(10, (i) => FlSpot(i.toDouble(), constante.k)),
                      isCurved: false,
                      color: colorFijo,
                      barWidth: 3,
                      dashArray: [8, 4],
                      dotData: const FlDotData(show: false),
                      belowBarData: BarAreaData(
                          show: true, color: colorFijo.withOpacity(0.08)),
                    ),
                  ],
                )),
              ),
            ),

            const SizedBox(height: 14),

            // Función cuadrática
            _card(
              title: '📐 Función cuadrática',
              subtitle: 'D(t) = 0.5t² + 10t + c (deuda)',
              child: SizedBox(
                height: 180,
                child: LineChart(LineChartData(
                  gridData: FlGridData(
                    show: true,
                    getDrawingHorizontalLine: (_) => FlLine(
                        color: Colors.white.withOpacity(0.05), strokeWidth: 1),
                  ),
                  borderData: FlBorderData(show: false),
                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 50,
                      getTitlesWidget: (v, _) => Text(v.toInt().toString(),
                          style: TextStyle(color: colorTextoSub, fontSize: 10)),
                    )),
                    bottomTitles: AxisTitles(sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (v, _) => Text(v.toInt().toString(),
                          style: TextStyle(color: colorTextoSub, fontSize: 10)),
                    )),
                    topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                  ),
                  lineBarsData: [
                    LineChartBarData(
                      spots: puntosCuadratica.asMap().entries
                          .map((e) => FlSpot(e.key.toDouble(), e.value)).toList(),
                      isCurved: true,
                      color: colorGasto,
                      barWidth: 3,
                      dotData: const FlDotData(show: false),
                      belowBarData: BarAreaData(
                          show: true, color: colorGasto.withOpacity(0.08)),
                    ),
                  ],
                )),
              ),
            ),

          ],
        ),
      ),
    );
  }

  Widget _card({required String title, required String subtitle, required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colorCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: colorCardBorde),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 10)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Colors.white)),
          Text(subtitle, style: TextStyle(fontSize: 12, color: colorTextoSub)),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }

  Widget _tramo(String rango, String nivel, Color color, bool activo) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: activo ? color : color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Text(nivel, style: TextStyle(
                color: activo ? Colors.white : color,
                fontWeight: FontWeight.bold, fontSize: 13)),
            Text(rango, style: TextStyle(
                color: activo ? Colors.white70 : color.withOpacity(0.7),
                fontSize: 11)),
          ],
        ),
      ),
    );
  }
}