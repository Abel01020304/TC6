import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../funciones/funcion_exponencial.dart';
import '../utils/constantes.dart';
import '../utils/formatear.dart';

class PrediccionScreen extends StatefulWidget {
  const PrediccionScreen({super.key});

  @override
  State<PrediccionScreen> createState() => _PrediccionScreenState();
}

class _PrediccionScreenState extends State<PrediccionScreen> {
  double _a0 = 5000;
  double _r  = 0.05;
  int    _t  = 10;

  @override
  Widget build(BuildContext context) {
    final funcion = FuncionExponencial(a0: _a0, r: _r);
    final puntos  = funcion.generarPuntos(_t);
    final final_  = funcion.calcular(_t.toDouble());
    final ganancia = final_ - _a0;

    return Scaffold(
      backgroundColor: colorFondo,
      appBar: AppBar(
        title: const Text('Predicción de ahorro', style: TextStyle(color: Colors.white)),
        backgroundColor: colorFondo,
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [

            // Tarjetas resumen
            Row(
              children: [
                _miniCard('Inicial', formatearMoneda(_a0), colorAhorro),
                const SizedBox(width: 10),
                _miniCard('Final', formatearMoneda(final_), colorIngreso),
                const SizedBox(width: 10),
                _miniCard('Ganancia', formatearMoneda(ganancia), colorDeuda),
              ],
            ),

            const SizedBox(height: 16),

            // Sliders
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: colorCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: colorCardBorde),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('⚙️ Configura tu ahorro',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: Colors.white)),
                  const SizedBox(height: 16),
                  _slider('💰 Ahorro inicial', formatearMoneda(_a0), _a0, 0, 50000,
                      (v) => setState(() => _a0 = v)),
                  _slider('📈 Tasa de interés', '${(_r * 100).toStringAsFixed(0)}%', _r, 0.01, 0.2,
                      (v) => setState(() => _r = v)),
                  _slider('📅 Años', '$_t años', _t.toDouble(), 1, 30,
                      (v) => setState(() => _t = v.toInt())),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Gráfica
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: colorCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: colorCardBorde),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('📊 A(t) = A₀ · eʳᵗ — Función exponencial',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.white)),
                  Text('Crecimiento del ahorro con interés compuesto',
                      style: TextStyle(fontSize: 12, color: colorTextoSub)),
                  const SizedBox(height: 16),
                  SizedBox(
                    height: 220,
                    child: LineChart(LineChartData(
                      gridData: FlGridData(
                        show: true,
                        getDrawingHorizontalLine: (_) => FlLine(
                            color: Colors.white.withOpacity(0.05), strokeWidth: 1),
                      ),
                      borderData: FlBorderData(show: false),
                      titlesData: FlTitlesData(
                        leftTitles: AxisTitles(sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 50,
                          getTitlesWidget: (v, _) => Text(v.toInt().toString(),
                              style: TextStyle(color: colorTextoSub, fontSize: 10)),
                        )),
                        bottomTitles: AxisTitles(sideTitles: SideTitles(
                          showTitles: true,
                          getTitlesWidget: (v, _) => Text(v.toInt().toString(),
                              style: TextStyle(color: colorTextoSub, fontSize: 10)),
                        )),
                        topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      ),
                      lineBarsData: [
                        LineChartBarData(
                          spots: puntos.asMap().entries
                              .map((e) => FlSpot(e.key.toDouble(), e.value)).toList(),
                          isCurved: true,
                          color: colorAhorro,
                          barWidth: 3,
                          dotData: const FlDotData(show: false),
                          belowBarData: BarAreaData(
                            show: true,
                            gradient: LinearGradient(
                              colors: [colorAhorro.withOpacity(0.25), colorAhorro.withOpacity(0.0)],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                          ),
                        ),
                      ],
                    )),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _miniCard(String label, String valor, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: colorCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.25)),
          boxShadow: [BoxShadow(color: color.withOpacity(0.08), blurRadius: 10)],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: TextStyle(fontSize: 11, color: colorTextoSub)),
            const SizedBox(height: 4),
            Text(valor, style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: color)),
          ],
        ),
      ),
    );
  }

  Widget _slider(String label, String valor, double current, double min, double max,
      Function(double) onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: TextStyle(fontSize: 13, color: colorTextoSub)),
            Text(valor, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.white)),
          ],
        ),
        Slider(
          value: current, min: min, max: max,
          activeColor: colorAhorro,
          inactiveColor: colorCardBorde,
          onChanged: onChanged,
        ),
        const SizedBox(height: 8),
      ],
    );
  }
}