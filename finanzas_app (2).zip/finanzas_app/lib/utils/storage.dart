import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/transaccion.dart';

class Storage {
  static const _key = 'transacciones';

  static Future<List<Transaccion>> cargar() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getStringList(_key) ?? [];
    return data.map((e) => Transaccion.fromMap(jsonDecode(e))).toList();
  }

  static Future<void> guardar(List<Transaccion> lista) async {
    final prefs = await SharedPreferences.getInstance();
    final data = lista.map((e) => jsonEncode(e.toMap())).toList();
    await prefs.setStringList(_key, data);
  }
}