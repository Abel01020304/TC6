import 'package:flutter/material.dart';
import '../models/transaccion.dart';
import 'storage.dart';

class FinanzasProvider extends ChangeNotifier {
  List<Transaccion> _transacciones = [];

  List<Transaccion> get transacciones => _transacciones;

  double get totalIngresos => _transacciones
      .where((t) => t.tipo == 'ingreso')
      .fold(0, (s, t) => s + t.monto);

  double get totalGastos => _transacciones
      .where((t) => t.tipo != 'ingreso')
      .fold(0, (s, t) => s + t.monto);

  double get ahorro => totalIngresos - totalGastos;

  Future<void> iniciar() async {
    _transacciones = await Storage.cargar();
    notifyListeners();
  }

  Future<void> agregar(Transaccion t) async {
    _transacciones.add(t);
    await Storage.guardar(_transacciones);
    notifyListeners();
  }
}