import 'package:intl/intl.dart';

String formatearMoneda(double monto) {
  final f = NumberFormat.currency(locale: 'es_MX', symbol: '\$');
  return f.format(monto);
}

String formatearFecha(DateTime fecha) {
  final f = DateFormat('dd/MM/yyyy', 'es_MX');
  return f.format(fecha);
}