import 'package:flutter/material.dart';

const Color colorIngreso  = Color(0xFF00E5A0);
const Color colorGasto    = Color(0xFFFF5C5C);
const Color colorAhorro   = Color(0xFF5B9BF8);
const Color colorDeuda    = Color(0xFFFFB347);
const Color colorFijo     = Color(0xFFB39DDB);

const Color colorFondo        = Color(0xFF0A0A0A);
const Color colorCard         = Color(0xFF1A1A1A);
const Color colorCardBorde    = Color(0xFF2A2A2A);
const Color colorTexto        = Color(0xFFFFFFFF);
const Color colorTextoSub     = Color(0xFF888888);

const double limiteAlerta = 3000;