class FuncionTramos {
  // Función por tramos según el gasto total
  String evaluarTramo(double gasto) {
    if (gasto <= 1000) {
      return 'basico';
    } else if (gasto <= 3000) {
      return 'medio';
    } else {
      return 'alto';
    }
  }

  String descripcionTramo(double gasto) {
    final tramo = evaluarTramo(gasto);
    switch (tramo) {
      case 'basico':
        return 'Gastos básicos — ahorro estable';
      case 'medio':
        return 'Gastos medios — ahorro moderado';
      case 'alto':
        return 'Gastos altos — dinero baja rápido';
      default:
        return '';
    }
  }
}