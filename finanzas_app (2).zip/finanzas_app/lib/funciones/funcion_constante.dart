class FuncionConstante {
  final double k; // gasto fijo mensual

  FuncionConstante({required this.k});

  // f(t) = k
  double calcular() {
    return k;
  }

  List<double> generarPuntos(int meses) {
    return List.generate(meses, (_) => k);
  }
}