import 'dart:math';

class FuncionExponencial {
  final double a0; // ahorro inicial
  final double r;  // tasa de interés

  FuncionExponencial({required this.a0, required this.r});

  // A(t) = A0 * e^(r * t)
  double calcular(double t) {
    return a0 * exp(r * t);
  }

  List<double> generarPuntos(int anos) {
    return List.generate(anos, (t) => calcular(t.toDouble()));
  }
}