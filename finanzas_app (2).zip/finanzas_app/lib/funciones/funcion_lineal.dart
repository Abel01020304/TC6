class FuncionLineal {
  final double m; // gasto por día
  final double b; // gasto inicial

  FuncionLineal({required this.m, required this.b});

  // G(t) = m * t + b
  double calcular(double t) {
    return m * t + b;
  }

  List<double> generarPuntos(int dias) {
    return List.generate(dias, (t) => calcular(t.toDouble()));
  }
}