class FuncionCuadratica {
  final double a;
  final double b;
  final double c;

  FuncionCuadratica({required this.a, required this.b, required this.c});

  // D(t) = a*t^2 + b*t + c
  double calcular(double t) {
    return a * t * t + b * t + c;
  }

  List<double> generarPuntos(int meses) {
    return List.generate(meses, (t) => calcular(t.toDouble()));
  }
}