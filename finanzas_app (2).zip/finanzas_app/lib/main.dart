import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'utils/finanzas_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final provider = FinanzasProvider();
  await provider.iniciar();
  runApp(
    ChangeNotifierProvider.value(
      value: provider,
      child: const FinanzasApp(),
    ),
  );
}

class FinanzasApp extends StatelessWidget {
  const FinanzasApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Finanzas App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0A0A0A),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF00E5A0),
          surface: Color(0xFF1A1A1A),
          background: Color(0xFF0A0A0A),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0A0A0A),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        sliderTheme: const SliderThemeData(
          activeTrackColor: Color(0xFF00E5A0),
          thumbColor: Color(0xFF00E5A0),
          inactiveTrackColor: Color(0xFF2A2A2A),
        ),
        dropdownMenuTheme: const DropdownMenuThemeData(
          menuStyle: MenuStyle(
            backgroundColor: MaterialStatePropertyAll(Color(0xFF1A1A1A)),
          ),
        ),
        inputDecorationTheme: const InputDecorationTheme(
          labelStyle: TextStyle(color: Color(0xFF888888)),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: Color(0xFF2A2A2A)),
          ),
          focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: Color(0xFF00E5A0)),
          ),
        ),
        useMaterial3: true,
      ),
      home: const LoginScreen(), // <-- cambiado aquí
    );
  }
}